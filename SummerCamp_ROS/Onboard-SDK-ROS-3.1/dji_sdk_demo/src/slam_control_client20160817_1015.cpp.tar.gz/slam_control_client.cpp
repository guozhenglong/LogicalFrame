#include <iostream>
#include <math.h>
#include "string"
#include <vector>
#include <unistd.h>
#include <sys/select.h>

// ros
#include <ros/ros.h>
//#include <std_msgs/Int32MultiArray.h>
#include "geometry_msgs/PoseStamped.h"
#include <std_msgs/Float32MultiArray.h>
#include "uav_vision/DetectInfo.h"

// opencv
#include <opencv2/opencv.hpp>

// dji
#include <dji_sdk/dji_drone.h>
#include <lonely_info/StatCtrl.h>
// ttyUSB
#include "commCtrl.h"
#include "../include/stdHeaders.h"
#define BUF_SIZE 3

// Simulation
#define REAL_WORLD

// namespace
using namespace std;
using namespace DJI::onboardSDK;

DJIDrone* drone;

// The control status we'll used
// The sort of uav control signals
enum uavCtrlSignal
{
    uavCsTakeOff            = 0x000100,
    uavCsLanding            = 0x000200,
    uavCsHangSlientNormal   = 0x000400,
    uavCsHangSlientForce    = 0x000800,
    uavCsBackParking        = 0x001000,
    uavCsMovDistance        = 0x002000,

    uavCsTakeGrip           = 0x080000,   // To hand
    uavCsTakeThrow          = 0x100000,   // To hand
    uavCsLeftCar            = 0x200000,   // To car
    uavCsRequestLanding     = 0x400000,   // To car
};
// The sort of uav mission status
enum uavStatusInfo
{
    uavStBusy        = 0x000002,
    uavStRunning     = 0x000004,
    uavStReady       = 0x000008,

    uavStFlight      = 0x000010,
    uavStHover       = 0x000020,
    uavStAtCar       = 0x000040,
    uavStFindObject  = 0x000080,

    uavStError       = 0x800000
};

// help
void help()
{
    cout << "   Welcome to use NBZD ORB_SLAM2 Drone by Monocular" << endl;
    cout << "                                       " << endl;
    cout << "                                       " << endl;
    cout << "                   *******             " << endl;
    cout << "                *************          " << endl;
    cout << "               *****      ****         " << endl;
    cout << "                        *****          " << endl;
    cout << "                       ****            " << endl;
    cout << "                      ****             " << endl;
    cout << "                    ****               " << endl;
    cout << "                  ***                  " << endl;
    cout << "               ****************        " << endl;
    cout << "               ****************        " << endl;
    cout << "                                       " << endl;
    cout << "                                       " << endl;
    cout << "      Please Choose the Drone Function:" << endl;
    cout << "          [G]rab                       " << endl;
    cout << "          [T]hrow                      " << endl;
    cout << "          [R]equest Control            " << endl;
    cout << "          [M]ove to Desired Point      " << endl;
    cout << "          [S]tatus                     " << endl;
    cout << "          [C]ompetition                " << endl;
    cout << "          [P]ark                       " << endl;
    cout << "          [L]et's SHOW                 " << endl;
    cout << "          [Q]uit                       " << endl;
    cout << "                                       " << endl;
    cout << "Input:";
}

// Input and End Loop
bool inputAvilable()
{
    struct timeval tv;
    fd_set fds;
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds);
    select(STDIN_FILENO + 1, &fds, NULL, NULL, &tv);
    return (FD_ISSET(0, &fds));
}

// Landmark:
    // 4 block:
    float ledDetectX1;
    float ledDetectY1;
    float ledDetectZ1;

    // 4 block throw:
    float ledThrowX1;
    float ledThrowY1;
    float ledThrowZ1;

    float carDetectX;
    float carDetectY;
    float carDetectZ;

// Parameter:
    // ORB_SLAM2 Mono Scale Coefficet
    float X_COE;
    float Y_COE;
    float Z_COE;

    // The Slam Drone Origin Point
    float originX = -108.0;
    float originY = 278.0;
    float originZ = 62.0; // 25.0

    //YAW angle
    float YAW;

    // The tty message
    char dev[13] = "/dev/ttyUSB1";
    uchar sendBuf[BUF_SIZE];

    // PID parameter
    struct PID
    {
        float kp;
        float ki;
        float kd;
        float maxVal;
        float minVal;
        float errThres;
        float errLed;
    };
    PID PIDX, PIDY, PIDZ;

    // Read PID Parameter
    void readParam()
    {
        memset(sendBuf, 0, BUF_SIZE);
        sendBuf[0] = '!';
        sendBuf[BUF_SIZE - 1] = '#';

        cv::FileStorage fs;
        fs.open("/home/qy/DroneRectifyParam.yml", cv::FileStorage::READ);

        X_COE = fs["X_COE"];
        Y_COE = fs["Y_COE"];
        Z_COE = fs["Z_COE"];

        ledDetectX1 = fs["landmarkX1"];
        ledDetectY1 = fs["landmarkY1"];
        ledDetectZ1 = fs["landmarkZ1"];

        ledThrowX1 = fs["landmarkX2"];
        ledThrowY1 = fs["landmarkY2"];
        ledThrowZ1 = fs["landmarkZ2"];

        carDetectX = fs["landmarkX3"];
        carDetectY = fs["landmarkY3"];
        carDetectZ = fs["landmarkZ3"];

        PIDX.kp = fs["x_kp"];
        PIDX.ki = fs["x_ki"];
        PIDX.kd = fs["x_kd"];
        PIDX.maxVal = fs["x_maxVal"];
        PIDX.minVal = fs["x_minVal"];
        PIDX.errThres = fs["x_err_thres"];
        PIDX.errLed   = fs["x_err_led"];

        PIDY.kp = fs["y_kp"];
        PIDY.ki = fs["y_ki"];
        PIDY.kd = fs["y_kd"];
        PIDY.maxVal = fs["y_maxVal"];
        PIDY.minVal = fs["y_minVal"];
        PIDY.errThres = fs["y_err_thres"];
        PIDY.errLed   = fs["y_err_led"];

        PIDZ.kp = fs["z_kp"];
        PIDZ.ki = fs["z_ki"];
        PIDZ.kd = fs["z_kd"];
        PIDZ.maxVal = fs["z_maxVal"];
        PIDZ.minVal = fs["z_minVal"];
        PIDZ.errThres = fs["z_err_thres"];
        PIDZ.errLed   = fs["z_err_led"];

        YAW = 	fs["YAW"];
    }


// Callback
    //slamCallback
    volatile float slamPosition[3] = {0.0};
    void slamCallback(const geometry_msgs::PoseStamped::ConstPtr& msgs)
    {
        slamPosition[0] = msgs->pose.position.x;
        slamPosition[1] = msgs->pose.position.y;
        slamPosition[2] = msgs->pose.position.z;
    }
    
    //markerCallback
    volatile float markerDiff[4] = {0.0};
    void markerCallback(const uav_vision::DetectInfo::ConstPtr& msgs)
    {
        markerDiff[0] = msgs->data.data[0];
        markerDiff[1] = msgs->data.data[1];
        markerDiff[2] = msgs->data.data[2];
        markerDiff[3] = msgs->data.data[3];
    }

    //guidanceCallback
    volatile float droneGuidanceInfo[9] = {0.0};
    void guidanceCallback(const uav_vision::DetectInfo::ConstPtr& msg) // Read Visual Odometry
	{
	    for (int i = 0;i < msg->data.data.size(); i++)
	    {
	        droneGuidanceInfo[i] = msg->data.data[i];
	    }
	    //droneVoInfo[5] = -droneVoInfo[5]; // Vo z axiz reverse
	    droneGuidanceInfo[7] = droneGuidanceInfo[7] / 1000; // Ultrasonic mm translate to m
	    //droneVoInfo[7] = droneVoInfo[5] * 0.2 + 0.8 * droneVoInfo[7]; // Flight Height sensor fusion!

	    //stringstream ss;
	    //  ultrasonic : tvec_z
	    //ss << droneGuidanceInfo[7] * 1000 << " : " << droneMarkerInfo[5] << endl;
	    //utFile << ss.str();
	}

	//ledCallback
	volatile float ledKind;
	void ledCallback(const uav_vision::DetectInfo::ConstPtr& msg)
	{
		ledKind = msg->data.data[0];
		cout << "I heard: " << ledKind << endl;
	}

// Drone Function:
void droneMove(float targetX, float targetY, float targetZ, float errThres)
{
    int endFlag = 0;

    float controlX;
    float controlY;
    float controlZ;
    float controlYaw = YAW;

    while (true)
    {
        ros::spinOnce();

	#ifdef REAL_WORLD
        float x = X_COE * slamPosition[0] - originX;
        float y = Y_COE * slamPosition[1] - originY;
        float z = Z_COE * slamPosition[2] - originZ;

        float xErr = (x - targetX) / 100; //  transilation CM to M
        float yErr = (y - targetY) / 100; //  transilation CM to M
        float zErr = (z - targetZ) / 100; //  transilation CM to M

	#else
        float theta = controlYaw / 180.0 * 3.141592654;

        float x = drone->local_position.x * cos(theta) + drone->local_position.y * sin(theta);
        float y = drone->local_position.y * cos(theta) - drone->local_position.x * sin(theta);
        float z = drone->local_position.z;

        float xErr = targetX / 100 - x; //  transilation CM to M
        float yErr = targetY / 100 - y; //  transilation CM to M
        float zErr = targetZ / 100 - z; //  transilation CM to M

	#endif

		cout << "x = " << x << "    xErr = " << xErr << endl;
		cout << "y = " << y << "    yErr = " << yErr << endl;
		cout << "z = " << z << "    zErr = " << zErr << endl;
        controlX = PIDX.kp * xErr;
        controlY = PIDY.kp * yErr;
        controlZ = PIDZ.kp * zErr;

        if (abs(controlX) > PIDX.maxVal)
        {
            if (controlX > 0)
            {
                controlX = PIDX.maxVal;
            }
            else
            {
                controlX = -PIDX.maxVal;
            }
        }

        if (abs(controlY) > PIDY.maxVal)
        {
            if (controlY > 0)
            {
                controlY = PIDY.maxVal;
            }
            else
            {
                controlY = -PIDY.maxVal;
            }
        }

        if (abs(controlZ) > PIDZ.maxVal)
        {
            if (controlZ > 0)
            {
                controlZ = PIDZ.maxVal;
            }
            else
            {
                controlZ = -PIDZ.maxVal;
            }
        }

        drone->attitude_control( Flight::HorizontalLogic::HORIZONTAL_VELOCITY |
                                 Flight::VerticalLogic::VERTICAL_VELOCITY |
                                 Flight::YawLogic::YAW_ANGLE |
                                 Flight::HorizontalCoordinate::HORIZONTAL_BODY |
                                 Flight::SmoothMode::SMOOTH_ENABLE,
                                 controlY,           // x
                                 controlX,          // y
                                 controlZ,         // z
                                 controlYaw);             // yaw

        if ( abs(xErr) < errThres && abs(yErr) < errThres && abs(zErr) < errThres)
        {
            endFlag++;
            if (endFlag > 15)
            {
                break;
            }
        }

    }
}

bool horizontalRectify(float errorDiffX, float errorDiffY)
{
	float bodyVx, bodyVy;
    float controlX;
    float controlY;
    float controlYaw = YAW;
    float theta = controlYaw / 180.0 * 3.141592654;

    #ifdef REAL_WORLD
        bodyVx = droneGuidanceInfo[0] * cos(theta) + droneGuidanceInfo[1] * sin(theta);
        bodyVy = droneGuidanceInfo[1] * cos(theta) - droneGuidanceInfo[0] * sin(theta);
    #else
        bodyVx = drone->velocity.vx * cos(theta) + drone->velocity.vy * sin(theta);
        bodyVy = drone->velocity.vy * cos(theta) - drone->velocity.vx * sin(theta);
    #endif

	controlX = PIDX.kp * errorDiffX + PIDX.kd * (-bodyVx);
    controlY = PIDY.kp * errorDiffY + PIDY.kd * (-bodyVy);

    // For protection
    controlX = controlX >  0.5 ?  0.5 : controlX;
    controlX = controlX < -0.5 ? -0.5 : controlX;

    controlY = controlY >  0.5 ?  0.5 : controlY;
    controlY = controlY < -0.5 ? -0.5 : controlY;

    drone->attitude_control( Flight::HorizontalLogic::HORIZONTAL_VELOCITY |
                             Flight::VerticalLogic::VERTICAL_VELOCITY |
                             Flight::YawLogic::YAW_ANGLE |
                             Flight::HorizontalCoordinate::HORIZONTAL_BODY |
                             Flight::SmoothMode::SMOOTH_ENABLE,
                             controlX,           // x
                             controlY,          // y
                             0,         // z
                             controlYaw);      // yaw

    usleep(20000);

    cout << "errorDiffX is :" << errorDiffX << endl;
    cout << "Control_x is  :" << controlX << endl;
    cout << "errorDiffY is :" << errorDiffY << endl;
    cout << "Control_y is  :" << controlY << endl;

    if ((abs(errorDiffX) < 0.023) && (abs(errorDiffY) < 0.023))
        return true;
    else
        return false;
}

bool verticalRectify(float errorDiffZ)
{
	float bodyVz;
    float controlZ;
    float controlYaw = YAW;
    float theta = controlYaw / 180.0 * 3.141592654;

    #ifdef REAL_WORLD
        bodyVz = droneGuidanceInfo[2];
    #else
        bodyVz = drone->velocity.vz;
    #endif

    controlZ = -(PIDZ.kp * errorDiffZ + PIDZ.kd * (-bodyVz)) ;    

    // For protection
    controlZ = controlZ >  0.2 ?  0.2 : controlZ;
    controlZ = controlZ < -0.2 ? -0.2 : controlZ;

    drone->attitude_control( Flight::HorizontalLogic::HORIZONTAL_VELOCITY |
                             Flight::VerticalLogic::VERTICAL_VELOCITY |
                             Flight::YawLogic::YAW_ANGLE |
                             Flight::HorizontalCoordinate::HORIZONTAL_BODY |
                             Flight::SmoothMode::SMOOTH_ENABLE,
                             0,           // x
                             0,          // y
                             controlZ,         // z
                             controlYaw);      // yaw

    cout << "errorDiffZ is :" << errorDiffZ << endl;
    cout << "Control_z is  :" << controlZ << endl;

    if (abs(errorDiffZ) < 0.65)
        return true;
    else
        return false;
}

void yawRectify(float errorDiffYaw)
{
	float controlYaw = YAW;
	ros::spinOnce();

	if ((controlYaw - errorDiffYaw) > 30.0)
	{
		for (int i = 0; i < 15; i++)
		{
			cout << errorDiffYaw << endl;

			drone->attitude_control( Flight::HorizontalLogic::HORIZONTAL_VELOCITY |
	                             Flight::VerticalLogic::VERTICAL_VELOCITY |
	                             Flight::YawLogic::YAW_ANGLE |
	                             Flight::HorizontalCoordinate::HORIZONTAL_BODY |
	                             Flight::SmoothMode::SMOOTH_ENABLE,
	                             0,           // x
	                             0,          // y
	                             0,         // z
	                             controlYaw - (errorDiffYaw / 2.0));      // yaw
			usleep(20000);
		}
		usleep(500000);
	}

	for (int i = 0; i < 15; i++)
	{
		cout << errorDiffYaw << endl;

		drone->attitude_control( Flight::HorizontalLogic::HORIZONTAL_VELOCITY |
                             Flight::VerticalLogic::VERTICAL_VELOCITY |
                             Flight::YawLogic::YAW_ANGLE |
                             Flight::HorizontalCoordinate::HORIZONTAL_BODY |
                             Flight::SmoothMode::SMOOTH_ENABLE,
                             0,           // x
                             0,          // y
                             0,         // z
                             controlYaw - errorDiffYaw);      // yaw

		usleep(20000);
	}
}

void markerRectify()
{
	float errorDiffX, errorDiffY, errorDiffZ, errorDiffYaw;

	bool horizontalFlag = false;
    bool verticalFlag = false;
    bool finishFlag = false;

    int turn = 0;

    while(!finishFlag)
    {
        ros::spinOnce();

        errorDiffX = -markerDiff[1];
        errorDiffY =  markerDiff[0];
	    errorDiffZ =  markerDiff[2];
	    errorDiffYaw = markerDiff[3];

    	if (!horizontalFlag)
    	{
    		if (horizontalRectify(errorDiffX, errorDiffY))
    			turn ++;
    		else 
    			turn = 0;

    		if (turn > 5)
    		{
    			horizontalFlag = true;
    			turn = 0;
    		}
    	}
    	else if (!verticalFlag)
    	{
    		if ((abs(errorDiffX) > 0.035) || (abs(errorDiffY) > 0.035))
    			horizontalFlag = false;

    		if (verticalRectify(errorDiffZ))
    			turn ++;
    		else 
    			turn = 0;

    		if (turn > 5)
    		{
    			verticalFlag = true;
    			horizontalFlag = false;
    			turn = 0;
    		}
    	}

    	if (horizontalFlag && verticalFlag)
    	{
    		finishFlag = true;
    	}
    }

    yawRectify(errorDiffYaw);
    sleep(1);
}

void droneStatus()
{
    //cout << "********* Drone Status *********" << endl;
    cout << "slamX = " << X_COE * slamPosition[0] - originX << endl;
    cout << "slamY = " << Y_COE * slamPosition[1] - originY << endl;
    cout << "slamZ = " << Z_COE * slamPosition[2] - originZ << endl;
}

void droneOctopus()
{

    // fly to 4 block
    int ledFlag = 0;
    droneMove(ledDetectX1, ledDetectY1, ledDetectZ1, PIDX.errLed);
    int missionNum = 0;
    while (ledKind != 2 && ledFlag < 5)
    {

        droneMove(ledDetectX1, ledDetectY1, ledDetectZ1, PIDX.errLed);
    	if (ledKind == 2)
    	{
    		ledFlag ++;
    	}

    }
   
        droneMove(ledThrowX1, ledThrowY1, ledThrowZ1, PIDX.errThres);
    	sendBuf[1] = 0;
		for (int i = 0; i < 30; i++)
		{
            commWrite(sendBuf, dev, BUF_SIZE);
		}
		sleep(3);
        missionNum = 1;
      // need fly high>??????
    if(missionNum == 1)
    {
        droneMove(carDetectX, carDetectY, carDetectZ, PIDX.errThres);
        //markerRectify();
        // drone->landing();
        // throw
        // sendBuf[1] = 0;
        // for (int i = 0; i < 30; i++)
        // {
        //     commWrite(sendBuf, dev, BUF_SIZE);
        // }
    }
}

void droneHippo()
{
	 
    // fly to 4 block
    int ledFlag = 0;
    droneMove(ledDetectX1, ledDetectY1, ledDetectZ1, PIDX.errLed);
    int missionNum = 0;
    while (ledKind != 1 && ledFlag < 5)
    {

        droneMove(ledDetectX1, ledDetectY1, ledDetectZ1, PIDX.errLed);
    	if (ledKind == 1)
    	{
    		ledFlag ++;
    	}

    }
   
        droneMove(ledThrowX1, ledThrowY1, ledThrowZ1, PIDX.errThres);
    	sendBuf[1] = 0;
		for (int i = 0; i < 30; i++)
		{
            commWrite(sendBuf, dev, BUF_SIZE);
		}
		sleep(3);
        missionNum = 1;
      // need fly high>??????
    if(missionNum == 1)
    {
        droneMove(carDetectX, carDetectY, carDetectZ, PIDX.errThres);
        //markerRectify();
        // drone->landing();
        // throw
        // sendBuf[1] = 0;
        // for (int i = 0; i < 30; i++)
        // {
        //     commWrite(sendBuf, dev, BUF_SIZE);
        // }
    }
}

// void droneShow()
// {
//     droneMove(-35,  -407, -120);
//     droneMove(-220, -315, -120);
//     droneMove(-412, -251, -120);
//     droneMove(-426, -141, -120);
//     droneMove(-390, -32,  -120);
//     droneMove(-195, -202, -120);
//     droneMove(-210, -342, -120);
//     droneMove(-102, -180, -120);
//     droneMove(-24, -27, -120);
//     cout << "Thank you!" << endl;

// }

bool respond4CoreLogic(lonely_info::StatCtrl::Request &req,
                       lonely_info::StatCtrl::Response &res)
{
    cout << "I get the request from core logic" << endl;
    bool ret;
    switch (req.ctrlSignal)
    {
    case uavCsTakeOff:
        ret = drone->request_sdk_permission_control();
        sleep(2);
        cout << "Request Permission Succesefully!" << endl;
        ret = drone->takeoff();
        sleep(2);
        if(ret) res.statusInfo = uavCsTakeOff | uavStReady;
        else    res.statusInfo = uavCsTakeOff | uavStError;
        break;
    case uavCsMovDistance:
        droneMove(req.errorX, req.errorY, req.errorZ, PIDX.errThres);
        res.statusInfo = uavCsMovDistance | uavStReady;
        break;
    case uavCsLanding:
        markerRectify();
        ret = drone->landing();
        if(ret) res.statusInfo = uavCsLanding | uavStReady;
        else    res.statusInfo = uavCsLanding | uavStError;
        break;
    case uavCsTakeThrow:
        sendBuf[1] = 0;
        for (int i = 0; i < 30; i++)
        {
           commWrite(sendBuf, dev, BUF_SIZE);
        }
        res.statusInfo = uavCsTakeThrow | uavStReady;
        break;
    }
}

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "slamDroneControl");
    ros::NodeHandle nh;
    ros::Rate loopRate(20);

    ros::Subscriber subSlam = nh.subscribe("ORB_SLAM/pose", 1000, slamCallback);
    ros::Subscriber subMarker = nh.subscribe("/uav_vision/markerDiffInfo", 50, markerCallback);
    ros::Subscriber subGuidance = nh.subscribe("/uav_guider/velPosByVo", 50, guidanceCallback);
    ros::Subscriber subLed = nh.subscribe("/uav_vision/detectLed", 50, ledCallback);

    readParam();

    ros::ServiceServer service = nh.advertiseService("/uav_ctrl/onboard", respond4CoreLogic);

    drone = new DJIDrone(nh);


    while (nh.ok())
     {
         ros::spinOnce();

         help();

         char command;
         cin >> command;

         // The Slam Drone Target Point
         float targetX = 0.0;
         float targetY = 0.0;
         float targetZ = 0.0;

         switch (command) {
         // grab message send 30 times
         case 'g':
             sendBuf[1] = 1;
             for (int i = 0; i < 30; i++)
             {
                commWrite(sendBuf, dev, BUF_SIZE);
             }
             break;
         case 't':
             sendBuf[1] = 0;
             for (int i = 0; i < 30; i++)
             {
                commWrite(sendBuf, dev, BUF_SIZE);
             }
             break;
         // request permission and take-off
         case 'R':
         	 sendBuf[1] = 1;
             for (int i = 0; i < 30; i++)
             {
                commWrite(sendBuf, dev, BUF_SIZE);
             }
             drone->request_sdk_permission_control();
             sleep(2);
             cout << "Request Permission Succesefully!" << endl;
             drone->takeoff();
             sleep(2);
             break;
         // move to target point
         case 'm':
             cout << "Please input the x:";
             cin >> targetX;
             cout << "Please input the y:";
             cin >> targetY;
             cout << "Please input the z:";
             cin >> targetZ;
             droneMove(targetX, targetY, targetZ, PIDX.errThres);
             break;
         // drone status
         case 's':
             for (int i = 0; i < 100; i++)
             {
                 droneStatus();
             }
             break;
         // competition mode
         case 'c':
             droneOctopus();
             sleep(5);
             markerRectify();
             drone->landing();
             sleep(5);
             break;
          case '1':
             droneHippo();
             sleep(5);
             markerRectify();
             drone->landing();
             sleep(5);
             break;
         // landing
         case 'p':
             drone->landing();
             break;
         // rectify
         case 'z':
             markerRectify();
             drone->landing();
             sleep(5);
             break;
         case 'y':
             yawRectify(markerDiff[3]);
             break;
       
         // quit
         case 'q':
             return 0;
         default:
             break;
         }

     }

    return 0;

}
