/** @file  Recorde the Guidance information for Fei Jia
 * @author DreamTale
 * @date   Jul 30, 2016
  */
// For sync
#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>

// Include std
#include <sstream>
#include <string>
#include <iostream>
#include <vector>
// Include ros and data transport headers
#include <ros/ros.h>
#include <sensor_msgs/image_encodings.h>
#include <std_msgs/String.h>
#include <std_msgs/Int16MultiArray.h>
#include <geometry_msgs/Point32.h>
#include <geometry_msgs/Vector3.h>
// Include image transport & bridge
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>

#include <std_msgs/Float32MultiArray.h>
#include <geometry_msgs/TransformStamped.h> //IMU
#include <geometry_msgs/Vector3Stamped.h> //velocity
#include <sensor_msgs/LaserScan.h> //obstacle distance & ultrasonic

#include <stdio.h>
#include <string.h>
#include <iostream>
#include <ros/ros.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/image_encodings.h>

#include <opencv2/opencv.hpp>
#include <cmath>

#include <fstream>
#include <sys/stat.h>
#include <string>
#include <sstream>

#include <time.h>

using namespace std;
using namespace cv;
using namespace message_filters;

string storagePath = "recodedVideos";
string videoTail = ".avi";
VideoWriter vw;
ofstream txtFile;

volatile long long myIndex = 0;
void callBackVideoWriter(const  cv_bridge::CvImage::ConstPtr& msgImg)
{

    Mat src = msgImg->image;

    vw << src;

    cout << "\rI have write " << myIndex++ << " frames. [use Ctrl-C to stop recording.]";
}

void setup()
{
    mkdir(storagePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    storagePath = storagePath + "/rawData";
    stringstream ss;
    ss << storagePath << ros::Time::now() << videoTail;
    storagePath = ss.str();
    cout << storagePath << endl;


    vw = VideoWriter(storagePath.c_str(), CV_FOURCC('M', 'J', 'P', 'G'), 20.0, Size(640, 480));
}

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "GuidanceRecoder");
    ros::NodeHandle nh;
    ros::Rate loopRate(20);

    setup();

    double lastTime = ros::Time::now().sec;

    ros::Subscriber subVideo = nh.subscribe<cv_bridge::CvImage>("/uav_cam/image", 5, callBackVideoWriter);


    while(nh.ok())
    {
        loopRate.sleep();
        ros::spinOnce();
    }


    double nowTime = ros::Time::now().sec;

    cout << endl << "Used " << nowTime - lastTime << " seconds." << endl;
    cout << "exited." << endl << endl;

    return 0;
}
